# Nacos 安装模板

本模板固定使用 `nacos/nacos-server:v3.2.4`，两种模式均为单机且开启客户端、管理端和控制台鉴权，不是生产高可用集群。Nacos 是内部基础组件，不建议直接暴露公网。

## 安装模式

- Standard：只部署 Nacos，连接已有 MySQL；安装前需建库、创建普通用户、授予数据库权限，并在所选数据库导入 `storage/mysql/init/01-schema.sql`。不要向已有 Nacos 数据库重复执行该 SQL，也不要将它当作升级脚本。
- Allin：部署 Nacos 和 `mysql:8.4.6`，MySQL 仅使用 Compose 默认网络，不发布宿主机端口。首次空数据目录启动时，镜像创建所选数据库、普通用户，并在该库执行初始化 SQL。Nacos 等待 MySQL 的 TCP 表查询成功后启动。

外部 MySQL 地址必须从 Nacos 容器可达；`127.0.0.1` 指向容器自身。复用本仓库独立 MySQL 时，可通过宿主机可达的内网地址及已发布端口连接，本模板不会自动加入 `mysql8_net`。

## 密钥与访问

安装菜单要求填写 JWT 密钥、服务端身份标识值及数据库密码，模板不提供共享密码。JWT 密钥可通过 `openssl rand -base64 48` 生成，须为有效 Base64 且解码后至少 32 字节；安装器只校验必填和编码字符串的最小长度，完整合法性由 Nacos 校验。管理员 `nacos` 的密码在首次进入控制台时初始化。

默认仅绑定宿主机 `127.0.0.1`：

| 用途 | 宿主机端口 | 容器端口 |
|------|------------|----------|
| 控制台 | 28080 | 8080 |
| 客户端 HTTP | 28848 | 8848 |
| 客户端 gRPC | 29848 | 9848 |

客户端 `serverAddr` 使用 HTTP 端口，而不是控制台端口。修改 HTTP 端口后，必须同时将 gRPC 宿主机端口设置为 HTTP 端口加 1000（HTTP 不超过 64535）；安装器不会自动推导或校验两个参数的关系。三个端口不能冲突。不发布单机模式不需要的集群内部端口。

通过 SSH 隧道访问控制台及本机 SDK：

```bash
ssh -N -L 28080:127.0.0.1:28080 -L 28848:127.0.0.1:28848 -L 29848:127.0.0.1:29848 用户@服务器
```

浏览器打开 `http://127.0.0.1:28080/`。远程业务客户端需要将绑定地址改为宿主机内网或 VPN 地址，并使用对应地址和 HTTP 端口；HTTP 反向代理不能替代 SDK 所需的 gRPC 通道。外部数据库跨不可信网络连接时，需按数据库要求修改 `.env` 的 `MYSQL_SERVICE_DB_PARAM`，配置 TLS；默认 JDBC 参数适合隔离网络。

## 持久化与更新

部署根目录默认为 `/data/dkapps/nacos/`，所有应用挂载均在 `storage/` 内：

- `data/`：Nacos 本地持久状态，完整保留。
- `logs/`：Nacos 日志，可在紧凑归档中排除。
- `mysql/data/`：Allin 的 MySQL 数据，完整保留。
- `mysql/init/01-schema.sql`：官方初始化 SQL，只在首次初始化使用；Standard 可手动导入。

挂载空的 `data/` 会遮蔽 3.2.4 镜像在该目录预置的 `skills-data.zip` 和 `agentspec-data.zip`，本模板不提供这些预置 AI 资源；如需它们，应在首次启动前从同版本官方镜像提取到应用 `storage/data/`，不要覆盖已有状态。

MySQL 数据目录非空时，修改 `.env` 不会重新建库、创建用户、导入 SQL 或更改数据库内密码。升级、改密码或切换模式前应先备份并单独完成数据库变更；Standard 与 Allin 切换不会自动迁移数据。`preserve` 保留已有配置，`overwrite` 会先备份配置，但都不会自动更新数据库表结构。

JVM 默认堆初始值为 `512m`、最大值为 `1g`，可通过 `.env` 调整 `JVM_XMS`、`JVM_XMX`、`JVM_XMN`；Allin 还需预留 MySQL、JVM 堆外内存和宿主机开销。

## SQL 来源

`01-schema.sql` 原样保留官方许可证，来自 Nacos `3.2.4`：

https://github.com/alibaba/nacos/blob/3.2.4/plugin-default-impl/nacos-default-datasource-plugin/nacos-datasource-plugin-mysql/src/main/resources/META-INF/mysql-schema.sql

SHA-256：`00f3148b049cc6c5cbfbbb8c92ffa608076d3ba1b0bc3ef78d4660d3caf0de5b`。
