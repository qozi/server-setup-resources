bind 127.0.0.1  注释掉，让所有机器可以连接
dir /var/lib/redis  注释掉，不存在该目录所以会报目录不存在的错误
logfile /logs/redis.log   设置日志路径为docker-compose.yml中映射的路径
appendonly yes  开启AOF持久化
requirepass 123456  设置连接密码


